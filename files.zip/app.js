/* =====================================================================
   Renders everything from data.js into the page.
   You do not need to edit this file to change your content \u2014 edit data.js.
   ===================================================================== */

(function () {
  "use strict";

  var D = window.PORTFOLIO || {};

  // Tiny helper: safe text into an element by selector.
  function set(sel, value) {
    var el = document.querySelector(sel);
    if (el) el.textContent = value;
  }

  /* ---- Identity ---- */
  document.title = D.name || "Portfolio";
  set("[data-name]", D.name);
  set("[data-eyebrow]", D.eyebrow);
  set("[data-tagline]", D.tagline);
  set("[data-domain]", D.domain);

  var logo = document.querySelector("[data-initials]");
  if (logo) logo.textContent = D.initials || "";

  var resumeBtn = document.querySelector("[data-resume]");
  if (resumeBtn && D.resumeFile) resumeBtn.setAttribute("href", D.resumeFile);

  set("[data-copy]", "\u00a9 " + new Date().getFullYear() + " \u00b7 " + (D.name || ""));

  /* ---- Metrics ---- */
  var mWrap = document.querySelector("[data-metrics]");
  if (mWrap && D.metrics) {
    D.metrics.forEach(function (m) {
      var card = document.createElement("div");
      card.className = "metric reveal";
      var v = document.createElement("div");
      v.className = "metric__value"; v.textContent = m.value;
      var l = document.createElement("div");
      l.className = "metric__label"; l.textContent = m.label;
      card.appendChild(v); card.appendChild(l);
      mWrap.appendChild(card);
    });
  }

  /* ---- Skills (0\u201310 block bars) ---- */
  var sWrap = document.querySelector("[data-skills]");
  if (sWrap && D.skills) {
    D.skills.forEach(function (s) {
      var lvl = Math.max(0, Math.min(10, s.level || 0));
      var row = document.createElement("div");
      row.className = "skill reveal";

      var head = document.createElement("div");
      head.className = "skill__name";
      var nm = document.createElement("span"); nm.textContent = s.name;
      var rk = document.createElement("span"); rk.className = "skill__rank"; rk.textContent = s.rank || "";
      head.appendChild(nm); head.appendChild(rk);

      var bar = document.createElement("div");
      bar.className = "skill__bar";
      bar.setAttribute("role", "img");
      bar.setAttribute("aria-label", s.name + ": " + lvl + " out of 10");
      for (var i = 0; i < 10; i++) {
        var block = document.createElement("i");
        if (i < lvl) block.className = "on";
        bar.appendChild(block);
      }
      row.appendChild(head); row.appendChild(bar);
      sWrap.appendChild(row);
    });
  }

  /* ---- Projects ---- */
  var pWrap = document.querySelector("[data-projects]");
  if (pWrap && D.projects) {
    D.projects.forEach(function (p) {
      var hasLink = p.url && p.url !== "#";
      var card = document.createElement(hasLink ? "a" : "div");
      card.className = "project reveal";
      if (hasLink) {
        card.setAttribute("href", p.url);
        card.setAttribute("target", "_blank");
        card.setAttribute("rel", "noopener");
      }

      var pips = document.createElement("div");
      pips.className = "project__pips";
      for (var i = 0; i < 3; i++) pips.appendChild(document.createElement("i"));

      var name = document.createElement("div");
      name.className = "project__name";
      name.appendChild(document.createTextNode(p.name));
      if (hasLink) {
        var ico = document.createElement("i");
        ico.className = "ti ti-external-link";
        ico.setAttribute("aria-hidden", "true");
        name.appendChild(ico);
      }

      var desc = document.createElement("div");
      desc.className = "project__desc"; desc.textContent = p.description;

      var tags = document.createElement("div");
      tags.className = "project__tags";
      (p.tags || []).forEach(function (t) {
        var tag = document.createElement("span");
        tag.className = "tag"; tag.textContent = t;
        tags.appendChild(tag);
      });

      card.appendChild(pips); card.appendChild(name);
      card.appendChild(desc); card.appendChild(tags);
      pWrap.appendChild(card);
    });
  }

  /* ---- Experience timeline ---- */
  var eWrap = document.querySelector("[data-experience]");
  if (eWrap && D.experience) {
    D.experience.forEach(function (x) {
      var row = document.createElement("div");
      row.className = "tl reveal";

      var rail = document.createElement("div");
      rail.className = "tl__rail";
      var node = document.createElement("span"); node.className = "tl__node";
      var line = document.createElement("span"); line.className = "tl__line";
      rail.appendChild(node); rail.appendChild(line);

      var body = document.createElement("div");
      var per = document.createElement("div"); per.className = "tl__period"; per.textContent = x.period;
      var role = document.createElement("div"); role.className = "tl__role"; role.textContent = x.role;
      var org = document.createElement("div"); org.className = "tl__org"; org.textContent = x.org;
      body.appendChild(per); body.appendChild(role); body.appendChild(org);
      if (x.detail) {
        var det = document.createElement("div"); det.className = "tl__detail"; det.textContent = x.detail;
        body.appendChild(det);
      }
      row.appendChild(rail); row.appendChild(body);
      eWrap.appendChild(row);
    });
  }

  /* ---- Education ---- */
  var edWrap = document.querySelector("[data-education]");
  if (edWrap && D.education) {
    D.education.forEach(function (e) {
      var card = document.createElement("div");
      card.className = "edu reveal";
      var t = document.createElement("div"); t.className = "edu__title"; t.textContent = e.title;
      var o = document.createElement("div"); o.className = "edu__org"; o.textContent = e.org;
      card.appendChild(t); card.appendChild(o);
      edWrap.appendChild(card);
    });
  }

  /* ---- Social / contact ---- */
  var fWrap = document.querySelector("[data-social]");
  if (fWrap && D.social) {
    D.social.forEach(function (s) {
      var a = document.createElement("a");
      a.setAttribute("href", s.url);
      if (s.url.indexOf("http") === 0) { a.setAttribute("target", "_blank"); a.setAttribute("rel", "noopener"); }
      if (s.icon) {
        var ico = document.createElement("i");
        ico.className = "ti ti-" + s.icon;
        ico.setAttribute("aria-hidden", "true");
        a.appendChild(ico);
      }
      a.appendChild(document.createTextNode(s.label));
      fWrap.appendChild(a);
    });
  }

  /* ---- Scroll reveal (skipped when reduced motion is on) ---- */
  var reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var items = document.querySelectorAll(".reveal");
  if (reduce || !("IntersectionObserver" in window)) {
    items.forEach(function (el) { el.classList.add("in"); });
  } else {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.add("in"); io.unobserve(en.target); }
      });
    }, { threshold: 0.12 });
    items.forEach(function (el) { io.observe(el); });
  }
})();
