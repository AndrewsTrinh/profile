/* =====================================================================
   YOUR CONTENT LIVES HERE.
   This is the ONLY file you normally need to edit.
   Change the text between the quotes, save, commit, push. That's it.
   (See README.md for the full guide.)
   ===================================================================== */

const PORTFOLIO = {

  /* ---- Identity ---- */
  name: "Andrew Trinh",          // Big pixel name in the hero
  initials: "AT",                // Logo in the top-left of the nav
  domain: "andrew.dev",          // Fake browser-bar label (cosmetic)
  eyebrow: "DATA · AML · RESEARCH",   // Small label above your name
  tagline: "Intelligence & analytics analyst building financial-crime detection systems and privacy-preserving AI.",

  /* ---- Resume file ---- */
  // Put your PDF in this folder named exactly "resume.pdf"
  // (or change the name below to match your file).
  resumeFile: "resume.pdf",

  /* ---- Metrics strip (the "at a glance" cards) ---- */
  // value = the big pixel number, label = the small caption under it.
  metrics: [
    { value: "5+",  label: "Years in AML" },
    { value: "67%", label: "Alert cut" },
    { value: "80%", label: "Report time \u2193" },
    { value: "70%", label: "True positive" }
  ],

  /* ---- Skills ---- */
  // level = 0 to 10 (fills that many blocks in the bar).
  // rank  = any short word you like (EXPERT / ADVANCED / PROFICIENT / LEARNING...).
  skills: [
    { name: "Python",                  level: 9,  rank: "EXPERT" },
    { name: "SQL",                     level: 9,  rank: "EXPERT" },
    { name: "Machine Learning",        level: 8,  rank: "ADVANCED" },
    { name: "Graph RAG \u00b7 Neo4j",  level: 8,  rank: "ADVANCED" },
    { name: "LLM Fine-tuning \u00b7 QLoRA", level: 7, rank: "PROFICIENT" },
    { name: "AML/CTF Typologies",      level: 10, rank: "EXPERT" }
  ],

  /* ---- Selected work / projects ---- */
  // url: link to the live project or repo. Use "" for no link.
  projects: [
    {
      name: "Typology Extractor",
      description: "Pulls AML typologies from AUSTRAC regulatory documents automatically using a Graph RAG pipeline.",
      tags: ["Graph RAG", "Neo4j", "LLM"],
      url: "https://typologyextractor.vercel.app"
    },
    {
      name: "Monitoring Engine",
      description: "Hybrid tiered detection stack with GBM alert scoring and SHAP explainability \u2014 cut alerts by 67%.",
      tags: ["ML", "SHAP", "AUSTRAC"],
      url: ""
    },
    {
      name: "UAR \u2192 SMR Automation",
      description: "Automated the reporting pipeline end to end, reducing manual reporting time by roughly 80%.",
      tags: ["Automation", "Python"],
      url: ""
    }
  ],

  /* ---- Experience (timeline) ---- */
  experience: [
    {
      period: "2020 \u2014 NOW",
      role: "Intelligence & Analytics Analyst",
      org: "Bendigo and Adelaide Bank",
      detail: "Transaction monitoring, typology extraction, and AI-driven AML/CTF compliance pipelines."
    },
    {
      period: "RESEARCH",
      role: "MPhil Candidate",
      org: "University of the Sunshine Coast",
      detail: "On-premise LLM distillation for privacy-preserving AML/CTF regulatory reasoning."
    }
  ],

  /* ---- Education & credentials ---- */
  education: [
    { title: "M.Sc Business Analytics", org: "Deakin University" },
    { title: "MPhil (in progress)",     org: "UniSC" },
    { title: "CFA Level 1",             org: "CFA Institute" }
  ],

  /* ---- Contact links (shown in the footer) ---- */
  // icon = a Tabler icon name (https://tabler.io/icons). Optional.
  social: [
    { label: "Email",    url: "mailto:you@example.com",            icon: "mail" },
    { label: "GitHub",   url: "https://github.com/yourusername",   icon: "brand-github" },
    { label: "LinkedIn", url: "https://linkedin.com/in/yourusername", icon: "brand-linkedin" }
  ]

};
