# Andrew Trinh — Portfolio

A small, fast, dependency-free personal site. Navy + light-brown palette, 8-bit
accents on a minimal layout. No build step, no framework — just open it.

---

## What's in here

| File | What it's for | Do you edit it? |
|------|----------------|-----------------|
| `data.js` | All your content: name, skills, projects, jobs, links | **Yes — this is the one.** |
| `resume.pdf` | Your downloadable resume | Replace with your real PDF |
| `index.html` | Page structure | Rarely |
| `styles.css` | Colours, fonts, spacing | Only for a look change |
| `app.js` | Renders `data.js` onto the page | No |
| `README.md` | This guide | No |

---

## Preview it on your computer

Double-click `index.html`. It opens in your browser and just works — no server needed.
Every time you edit `data.js`, save and refresh the browser to see the change.

---

## Update your content (the 90% case)

Open `data.js` in any text editor. Everything is labelled. Edit the text between the
quotes, save, refresh.

**Change a skill level** — `level` is 0–10 (how many blocks fill), `rank` is the label:
```js
{ name: "Python", level: 9, rank: "EXPERT" },
```

**Add a project** — copy a block, change the fields. `url: ""` means no link.
```js
{
  name: "New Project",
  description: "One sentence on what it does.",
  tags: ["Python", "ML"],
  url: "https://github.com/yourusername/new-project"
},
```

**Change the metric cards** (the “at a glance” numbers):
```js
{ value: "5+", label: "Years in AML" },
```

**Add a job** — under `experience`, copy a block:
```js
{ period: "2018 — 2020", role: "Analyst", org: "Some Company", detail: "What you did." },
```

**Update your links** — under `social`, swap the placeholder URLs for your real ones:
```js
{ label: "GitHub", url: "https://github.com/YOURNAME", icon: "brand-github" },
```
Icon names come from https://tabler.io/icons (use the name without `ti-`).

**Swap the resume** — drop your PDF into this folder and name it `resume.pdf`
(or keep your own name and update `resumeFile` in `data.js`).

---

## Change the colours (optional)

Open `styles.css`. The top block (`:root`) holds every colour in one place:
```css
--navy: #16233d;   /* main dark */
--tan:  #c9a876;   /* light-brown accent */
--cream:#f4ede4;   /* light sections */
```
Change a hex value, save, refresh. That's the whole palette.

---

## Put it online with GitHub Pages (free)

### Option A — all in the browser (no command line)

1. Go to https://github.com/new and create a repo. Name it **`yourusername.github.io`**
   (use your real GitHub username) and make it **Public**.
2. On the new repo page, click **uploading an existing file**.
3. Drag in **all** the files from this folder (`index.html`, `styles.css`, `app.js`,
   `data.js`, `resume.pdf`, `README.md`). Click **Commit changes**.
4. Wait ~1 minute. Your site is live at **`https://yourusername.github.io`**.

Because the repo is named `yourusername.github.io`, Pages turns on automatically.

### Option B — with git on your machine

```bash
# inside this folder
git init
git add .
git commit -m "Initial portfolio"
git branch -M main
git remote add origin https://github.com/YOURNAME/YOURNAME.github.io.git
git push -u origin main
```
Then on GitHub: **Settings → Pages → Build and deployment → Source: Deploy from a
branch → Branch: `main` / root → Save.** Live in ~1 minute at
`https://YOURNAME.github.io`.

> Prefer a repo with a different name (e.g. `portfolio`)? That works too — your site
> just lives at `https://YOURNAME.github.io/portfolio/`. Turn Pages on the same way
> (Settings → Pages → Branch `main` / root).

---

## Updating after it's live

Every time you want to change something:

1. Edit `data.js` (and refresh locally to check).
2. Commit and push:
   ```bash
   git add .
   git commit -m "Update skills and add a project"
   git push
   ```
3. GitHub Pages redeploys in about a minute.

If you used the browser upload method, just edit `data.js` directly on GitHub
(pencil icon → edit → **Commit changes**) or re-upload the file.

---

## Custom domain (optional)

In **Settings → Pages → Custom domain**, enter your domain and follow the DNS
instructions GitHub shows. Add a `CNAME` file (GitHub creates it for you) and you're set.

---

## Troubleshooting

- **Fonts or icons look plain** — you need to be online the first time; they load from
  Google Fonts and a CDN. After that browsers cache them.
- **Resume button downloads nothing** — make sure `resume.pdf` is in the same folder and
  the name matches `resumeFile` in `data.js`.
- **A section is empty** — check `data.js` for a missing comma or an unmatched quote. The
  browser console (F12) will point to the line.
- **Changes not showing after push** — give Pages a minute, then hard-refresh
  (Ctrl/Cmd + Shift + R).
